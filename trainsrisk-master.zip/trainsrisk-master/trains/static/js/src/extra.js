// var exports = module.exports = {};
var a = 1122;
export {a}